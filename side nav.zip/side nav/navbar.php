<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="fontawesome-free-6.0.0-web\css\all.min.css">
<link rel="stylesheet" href="style/style.css">
</head>
<body>
<?php 
    include "koneksi.php";
   ?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="index.php"><i class="fas fa-home"></i>Home</a>
  <a href="about.php"> <i class="fas fa-info-circle"></i>About</a>
  <a href="des.php"><i class="fas fa-map-marker-alt"></i>Destinasi</a>
  <a href="contact.php"><i class="fas fa-envelope"></i>Pesan tiket</a>
</div>


<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script src="java/jscript.js"></script>
   
</body>
</html> 
