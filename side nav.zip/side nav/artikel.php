<html>
<head>
	<title>Asia Tour | info</title>
	li
</head>
<body>
<?php 
    include "navbar.php";
    include "koneksi.php";
   ?>
<br>

<div class="header">
<h1>Asia Tour</h1>
<p>saatnya berpergian dengan asia tour</p>
</div>


<div class="row">
<div class="leftcolumn">
<div class="card">
<h2>ARTIKEL</h2>
<h5>sejarah</h5>
<img src="asset/logo.png" style="width:100px;"></img>
<p>Asia Tour didirikan pada tahun 1972 oleh sekelompok pengusaha muda di Jakarta dengan tujuan menyediakan layanan travel dan tour berkualitas. Pada tahun 1975, perusahaan ini mulai menawarkan paket wisata internasional ke beberapa negara Asia Tenggara. Ekspansi lebih lanjut dilakukan pada tahun 1980 dengan membuka cabang di Surabaya dan Bali, serta memperkenalkan sistem pemesanan tiket elektronik pada tahun 1985. Memasuki era 1990-an, Asia Tour meluncurkan situs web pada tahun 1996 dan menerapkan sistem manajemen kualitas ISO 9001 pada tahun 2000. Tahun 2002, Asia Tour melakukan merger dengan beberapa perusahaan travel lokal, dan pada tahun 2005 membuka kantor perwakilan di Singapura dan Kuala Lumpur. Inovasi terus berlanjut dengan peluncuran aplikasi mobile pertama pada tahun 2008 dan platform e-commerce pada tahun 2012. Tahun 2015, Asia Tour melakukan rebranding dan mendirikan divisi MICE pada tahun 2018. Menghadapi pandemi COVID-19 pada tahun 2020, perusahaan beradaptasi dengan layanan virtual tour dan meningkatkan fokus pada wisata domestik. Pada tahun 2022, Asia Tour merayakan 50 tahun berdirinya dengan peluncuran layanan baru yang inovatif, seperti paket wisata berbasis pengalaman lokal dan eco-tourism. Dengan komitmen terhadap kualitas layanan dan adaptasi terhadap 
	perubahan tren, Asia Tour terus menjadi pemain utama dalam industri pariwisata di Indonesia dan Asia Tenggara.</p>
</div>



<div class="card">
<h2>ARTIKEL</h2>
<h5></h5>
<img src="img/p2.jpg"  style="width:100px;"></img>
<p>sekilas info</p>
<p>Asia Tour adalah sebuah perusahaan travel dan tour terkemuka di Indonesia yang menyediakan berbagai layanan perjalanan wisata baik domestik maupun internasional. Didirikan pada tahun 1972, Asia Tour telah berkembang menjadi salah satu penyedia layanan wisata terbesar dan paling terpercaya di Indonesia. Perusahaan ini menawarkan berbagai paket wisata yang mencakup tujuan populer di dalam negeri seperti Bali, Yogyakarta, dan Lombok, serta destinasi internasional seperti Singapura, Malaysia, Thailand, Eropa, dan Amerika. Selain itu, Asia Tour juga menyediakan layanan pemesanan tiket pesawat, hotel, dan penyelenggaraan acara korporat (MICE: Meetings, Incentives, Conferences, and Exhibitions). Dengan komitmen terhadap inovasi dan kualitas layanan, Asia Tour terus beradaptasi dengan perkembangan teknologi dan tren pariwisata global, memastikan pengalaman perjalanan yang memuaskan dan tak terlupakan bagi para pelanggannya.

</div>
</div>
<div class="rightcolumn">
<div class="card">
	<h2>CEO</h2>
	<img src="asset/dk.jpg" style="width:100px;"></img>
	<p>Nama: Dk<br>
       pekerjaan: CEO
	pemilik perusahaan asia tour <br>
    </p>
</div>


<div class="card">
	<h2>follow me</h2>
	<p>tanya lebih lanjut lewat medsos @asiatour_123</p>

	
</div>
</div>
</div>
<div class="footer">
	<h3>copyright SALSA KELAS XI RPL 3</h3>
	
</div>
</body>
</html> 