<?php 
include("koneksi.php"); 
include "navbar.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Data Tamu</title>
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.css">
    <!-- Tambahkan CSS DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center">Daftar Buku Tamu</h2>
        <a href="contact.php" class="btn btn-success mb-3">Tambah Data</a>
        <table id="dataTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Pemesanan</th>
                    <th>Tanggal Keberangkatan</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Judul</th>
                    <th>Tipe Paket</th>
                    <th>Jumlah Orang</th>
                    <th>Harga Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Mengambil data dari database
                $sql = "SELECT * FROM tamu";
                $query = $conn->query($sql);

                if ($query && $query->num_rows > 0) {
                    $no = 1;
                    while ($row = $query->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $no++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['tanggal']) . "</td>"; // Tanggal otomatis
                        echo "<td>" . htmlspecialchars($row['tanggal_keberangkatan']) . "</td>"; // Tanggal keberangkatan manual
                        echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['judul']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['tipe_paket']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['jumlah_orang']) . "</td>";
                        echo "<td>Rp " . number_format($row['harga_total'], 0, ',', '.') . "</td>";
                        echo "<td>
                                <a href='edit.php?id=" . htmlspecialchars($row['id']) . "' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='hapus.php?id=" . htmlspecialchars($row['id']) . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Yakin ingin menghapus data ini?\")'>Hapus</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='10' class='text-center'>Tidak ada data</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
        <a href="contact.php" class="btn btn-primary">Kembali</a>
    </div>

    <!-- Tambahkan Script DataTables -->
    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable({
                "pageLength": 5, // Set jumlah entri default per halaman menjadi 5
                "lengthMenu": [5, 10, 25, 50, 100], // Pilihan jumlah entri per halaman
                "language": {
                    "lengthMenu": "Tampilkan _MENU_ entri per halaman",
                    "zeroRecords": "Tidak ada data yang ditemukan",
                    "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
                    "infoEmpty": "Tidak ada data tersedia",
                    "infoFiltered": "(difilter dari total _MAX_ entri)",
                    "search": "Cari:",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Berikutnya",
                        "previous": "Sebelumnya"
                    }
                }
            });
        });
    </script>
</body>

</html>
