<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="asset/logo.png" type="image/x-icon" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />
  <link rel="stylesheet" href=".css" />
  <title>Asian Tour||Destinasi</title>
</head>

<body id="home">
<?php 
    include "navbar.php";
    include "koneksi.php";
   ?>

</div>
 <div class="container-fluid destination">
    <h2 align="center" id="Tour">Paket Tour</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4">
      <div class="col">
        <h2>PAKET A</h2>
        <div class="card" style="width: 100%;">
          <img src="asset/singapore.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Singapore</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Singapura<br />
              Tanggal Keberangkatan: 11 sep 2024<br />
              Durasi Tour: 5 Hari<br />
              Harga: 8.000.000/org</br>
            (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
            </p>
            <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET B</h2>
        <div class="card" style="width: 100%;">
          <img src="asset/indo.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Indonesia</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Jawa<br />
              Tanggal Keberangkatan: 4 agus 2024<br />
              Durasi Tour: 8 Hari<br />
              Harga: 7.500.000/org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
            </p>
            <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET C</h2>
        <div class="card">
          <img src="asset/malay.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Malaysia</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Malaysia<br />
              Tanggal Keberangkatan: 4 okt 2024<br />
              Durasi Tour: 7 Hari<br />
              Harga: 9.500.000/org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
             </p>
             <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET D</h2>
        <div class="card">
          <img src="asset/japan.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Japan</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Japan<br />
              Tanggal Keberangkatan: 15 nov 2024<br />
              Durasi Tour: 10 Hari<br />
              Harga: 15.000.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
            </p>
            <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET E</h2>
        <div class="card">
          <img src="asset/cina.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">China</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Chinna<br />
              Tanggal Keberangkatan: 15 Des 2024<br />
              Durasi Tour: 10 Hari<br />
              Harga: 12.000.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
             </p>
             <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET F</h2>
        <div class="card">
          <img src="asset/south-korea.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">South Korea</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: South Korea<br />
              Tanggal Keberangkatan: 15 Des 2024<br />
              Durasi Tour: 9 Hari<br />
              Harga: 10.500.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
            </p>
            <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
    </div>
    <br />
    <h2 align="center" id="intercity"></h2>
    <br />
    <div class="row row-cols-1 row-cols-md-3 g-4">
      <div class="col">
        <h2>PAKET G</h2>
        <div class="card">
          <img src="asset/thai.webp" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Thailand</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Thailand<br />
              Tanggal Keberangkatan: 14 Mei 2024<br />
              Durasi Tour: 7 Hari<br />
              Harga: 9.000.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
              </p>
              <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET H</h2>
        <div class="card">
          <img src="asset/turki.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Turki</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Turki<br />
              Tanggal Keberangkatan: 14 jun 2024<br />
              Durasi Tour: 12 Hari<br />
              Harga: 15.000.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
              </p>
              <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET I</h2>
        <div class="card">
          <img src="asset/fran.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">France</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: France<br />
              Tanggal Keberangkatan: 20 jul 2024<br />
              Durasi Tour: 12 Hari<br />
              Harga: 14.000.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
            </p>
            <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET J</h2>
        <div class="card">
          <img src="asset/viet.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Vietnam</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Vietnam<br />
              Tanggal Keberangkatan: 1 jan 2025<br />
              Durasi Tour: 10 Hari<br />
              Harga: 9.500.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
              </p>
              <button class="btn btn-info detail-btn">Detail</button>

<!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
<div class="options" style="display: none; margin-top: 10px;">
  <button class="btn btn-primary agree-btn">Setuju</button>
  <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
</div>
</div>
</div>
</div>
      <div class="col">
        <h2>PAKET K</h2>
        <div class="card">
          <img src="asset/itali.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Itali</h5>
            <p class="card-text">Perusahaan: Asian Tour and Travel<br />
              Tujuan: Itali<br />
              Tanggal Keberangkatan: 15 feb 2025<br />
              Durasi Tour: 14 Hari<br />
              Harga: 16.000.000 /org</br>
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata, dan layanan pemandu)</br>
            </p>
            <button class="btn btn-info detail-btn">Detail</button>

              <!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
              <div class="options" style="display: none; margin-top: 10px;">
                <button class="btn btn-primary agree-btn">Setuju</button>
                <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
              </div>
              </div>
              </div>
              </div>
      <div class="col">
        <h2>PAKET L</h2>
        <div class="card">
          <img src="asset/belan.jpg" class="card-img-top" style="height: 285px;" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">Belanda</h5>
            <p class="card-text">
              Perusahaan: Asian Tour and Travel<br />
              Tujuan: Belanda<br />
              Tanggal Keberangkatan: 28 Mar 2025<br />
              Durasi Tour: 8 Hari<br />
              Harga: 11.000.000 /org<br />
              (Harga termasuk akomodasi, transportasi, makan, tiket masuk ke tempat wisata)
            </p>
            <!-- Tombol Detail -->
            <button class="btn btn-info detail-btn">Detail</button>

            <!-- Opsi Setuju / Tidak Setuju (disembunyikan) -->
            <div class="options" style="display: none; margin-top: 10px;">
              <button class="btn btn-primary agree-btn">Setuju</button>
              <button class="btn btn-secondary disagree-btn">Tidak Setuju</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Tambahkan paket lain di sini dengan struktur yang sama -->
    </div>
  </div>

  <!-- Tambahkan script JavaScript -->
  <script>
    // Ambil semua tombol detail
    const detailButtons = document.querySelectorAll(".detail-btn");

    detailButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const cardBody = this.parentElement; // Hanya memengaruhi tombol di dalam kartu ini
        const optionsDiv = cardBody.querySelector(".options");

        // Toggle visibility (tampilkan jika tersembunyi, sembunyikan jika sudah terlihat)
        if (optionsDiv.style.display === "none" || optionsDiv.style.display === "") {
          optionsDiv.style.display = "block";
        } else {
          optionsDiv.style.display = "none";
        }
      });
    });

    // Event listener untuk tombol "Setuju" dan "Tidak Setuju"
    document.addEventListener("click", function (event) {
      if (event.target.classList.contains("agree-btn")) {
        alert("Anda telah menyetujui pemesanan.");
        window.location.href = "https://wa.me/"; // Redirect ke WhatsApp
      }
      if (event.target.classList.contains("disagree-btn")) {
        alert("Anda tidak menyetujui pemesanan.");
      }
    });
  </script>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>