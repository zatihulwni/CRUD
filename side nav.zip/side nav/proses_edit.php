<?php
include("koneksi.php");

// Periksa apakah parameter 'id' ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Periksa apakah form dikirim menggunakan metode POST
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $judul = $_POST['judul'];
        $tanggal_keberangkatan = $_POST['tanggal_keberangkatan'];
        $jumlah_orang = $_POST['jumlah_orang'];
        $tipe_paket = $_POST['tipe_paket'];

        // Daftar harga per paket
        $harga_paket = [
            "A" => 500000, "B" => 600000, "C" => 700000, "D" => 800000,
            "E" => 900000, "F" => 1000000, "G" => 1100000, "H" => 1200000,
            "I" => 1300000, "J" => 1400000, "K" => 1500000, "L" => 1600000
        ];

        // Hitung total harga
        $harga_total = isset($harga_paket[$tipe_paket]) ? $harga_paket[$tipe_paket] * $jumlah_orang : 0;

        // Query untuk memperbarui data tamu
        $stmt = $conn->prepare("UPDATE tamu SET 
                    nama = ?, 
                    email = ?, 
                    judul = ?, 
                    tanggal_keberangkatan = ?, 
                    jumlah_orang = ?, 
                    tipe_paket = ?, 
                    harga_total = ? 
                WHERE id = ?");
        $stmt->bind_param(
            "ssssissi",
            $nama,
            $email,
            $judul,
            $tanggal_keberangkatan,
            $jumlah_orang,
            $tipe_paket,
            $harga_total,
            $id
        );

        if ($stmt->execute()) {
            header("Location: tampil.php"); // Arahkan kembali ke daftar tamu
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
} else {
    die("ID tidak valid.");
}

$conn->close();
?>
