<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="asset/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.css">
    <link rel="stylesheet" href="fontawesome-free-6.0.0-web/css/all.min.css">
    <title>Asia Tour | Kontak</title>
    <style>
        .wrapper {
            max-width: 500px;
            margin: 50px auto;
        }
    </style>
    <script>
        function setTanggalOtomatis() {
            const tanggalHariIni = new Date().toISOString().split('T')[0];
            document.getElementById("tanggal").value = tanggalHariIni;
        }

        function hitungHarga() {
            const hargaPaket = {
                "A": 500000, "B": 600000, "C": 700000, "D": 800000,
                "E": 900000, "F": 1000000, "G": 1100000, "H": 1200000,
                "I": 1300000, "J": 1400000, "K": 1500000, "L": 1600000
            };

            const tipePaket = document.getElementById("tipe_paket").value;
            const jumlahOrang = parseInt(document.getElementById("jumlah_orang").value) || 0;

            const totalHarga = (hargaPaket[tipePaket] || 0) * jumlahOrang;

            document.getElementById("harga_total").value = totalHarga.toLocaleString("id-ID", {
                style: "currency",
                currency: "IDR"
            });
        }
    </script>
</head>
<body onload="setTanggalOtomatis()">
    <?php 
    include "navbar.php";
    include "koneksi.php";

    $nama = $email = $judul = $pesan = $tipe_paket = $tanggal = $jumlah_orang = "";
    $nama_err = $email_err = $judul_err = $tipe_paket_err = $tanggal_err = $jumlah_orang_err = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama = trim($_POST["nama"]);
        $nama_err = empty($nama) ? "Masukkan nama." : "";

        $email = trim($_POST["email"]);
        if (empty($email)) {
            $email_err = "Masukkan email.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_err = "Format email tidak valid.";
        }

        $judul = trim($_POST["judul"]);
        $judul_err = empty($judul) ? "Masukkan judul." : "";

        $tipe_paket = trim($_POST["tipe_paket"]);
        $tipe_paket_err = empty($tipe_paket) ? "Pilih tipe paket." : "";

        $tanggal = trim($_POST["tanggal"]);
        $tanggal_err = empty($tanggal) ? "Tanggal otomatis tidak valid." : "";

        $tanggal_keberangkatan = trim($_POST["tanggal_keberangkatan"]);
        $tanggal_keberangkatan_err = empty($tanggal_keberangkatan) ? "Masukkan tanggal keberangkatan." : "";

        $jumlah_orang = trim($_POST["jumlah_orang"]);
        if (empty($jumlah_orang)) {
            $jumlah_orang_err = "Masukkan jumlah orang.";
        } elseif (!is_numeric($jumlah_orang) || $jumlah_orang <= 0) {
            $jumlah_orang_err = "Jumlah orang harus lebih dari 0.";
        }

        $harga_paket = [
            "A" => 500000, "B" => 600000, "C" => 700000, "D" => 800000,
            "E" => 900000, "F" => 1000000, "G" => 1100000, "H" => 1200000,
            "I" => 1300000, "J" => 1400000, "K" => 1500000, "L" => 1600000
        ];
        $harga_total = isset($harga_paket[$tipe_paket]) ? $harga_paket[$tipe_paket] * $jumlah_orang : 0;

        if (empty($nama_err) && empty($email_err) && empty($judul_err) && empty($tipe_paket_err) && empty($tanggal_err) && empty($tanggal_keberangkatan_err) && empty($jumlah_orang_err)) {
            $sql = "INSERT INTO tamu (nama, email, judul, tipe_paket, tanggal, tanggal_keberangkatan, jumlah_orang, harga_total) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            if ($stmt = mysqli_prepare($conn, $sql)) {
                mysqli_stmt_bind_param($stmt, "ssssssis", $nama, $email, $judul, $tipe_paket, $tanggal, $tanggal_keberangkatan, $jumlah_orang, $harga_total);
                if (mysqli_stmt_execute($stmt)) {
                    header("Location: tampil.php");
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
                }
            }
        }
        mysqli_close($conn);
    }
    ?>

    <div class="wrapper">
        <h2>Form Pemesanan</h2>
        <p>Isi form berikut untuk memesan paket tour.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <!-- Input Nama -->
            <div class="form-group mb-3">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control <?php echo (!empty($nama_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $nama; ?>">
                <div class="invalid-feedback"><?php echo $nama_err; ?></div>
            </div>

            <!-- Input Email -->
            <div class="form-group mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <div class="invalid-feedback"><?php echo $email_err; ?></div>
            </div>

            <!-- Input Judul -->
            <div class="form-group mb-3">
                <label>Judul</label>
                <input type="text" name="judul" class="form-control <?php echo (!empty($judul_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $judul; ?>">
                <div class="invalid-feedback"><?php echo $judul_err; ?></div>
            </div>

            <!-- Input Tanggal Otomatis -->
            <div class="form-group mb-3">
                <label>Tanggal Pemesanan</label>
                <input type="date" id="tanggal" name="tanggal" class="form-control" readonly>
            </div>

            <!-- Input Tanggal Keberangkatan -->
            <div class="form-group mb-3">
                <label>Tanggal Keberangkatan</label>
                <input type="date" name="tanggal_keberangkatan" class="form-control <?php echo (!empty($tanggal_keberangkatan_err)) ? 'is-invalid' : ''; ?>">
                <div class="invalid-feedback"><?php echo $tanggal_keberangkatan_err; ?></div>
            </div>

            <!-- Input Jumlah Orang -->
            <div class="form-group mb-3">
                <label>Jumlah Orang</label>
                <input type="number" id="jumlah_orang" name="jumlah_orang" class="form-control <?php echo (!empty($jumlah_orang_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $jumlah_orang; ?>" oninput="hitungHarga()">
                <div class="invalid-feedback"><?php echo $jumlah_orang_err; ?></div>
            </div>

            <!-- Input Tipe Paket -->
            <div class="form-group mb-3">
                <label>Tipe Paket</label>
                <select id="tipe_paket" name="tipe_paket" class="form-control <?php echo (!empty($tipe_paket_err)) ? 'is-invalid' : ''; ?>" onchange="hitungHarga()">
                    <option value="" disabled selected>Pilih Paket</option>
                    <?php
                    $paket_options = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"];
                    foreach ($paket_options as $paket) {
                        echo "<option value=\"$paket\" " . ($tipe_paket == $paket ? "selected" : "") . ">$paket</option>";
                    }
                    ?>
                </select>
                <div class="invalid-feedback"><?php echo $tipe_paket_err; ?></div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="tampil.php" class="btn btn-secondary">Lihat Data</a>
        </form>
    </div>
</body>
</html>
