<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="asset/logo.png" type="image/x-icon" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />
    <link rel="stylesheet" href="style/style1.css">
    <title>Asia Tour||About</title>
</head>
<body>
    <?php 
    include "navbar.php";
   ?>

   <div class="container-fluid about">
    <h2 id="about">About</h2>
    <div class="card mb-3" style="max-width: 100%; padding:30px;">
      <div class="row g-0">
        <div class="col-md-4">
          <img src="./asset/about.jpg" class="img-fluid rounded-start" alt="...">
        </div>
        <div class="col-md-8">
          <div class="card-body">
            <marquee><h3 class="card-title">Asian Tour And Travel</h3></marquee>
            <p>Asian Tour and Travel adalah perusahaan perjalanan terkemuka yang berbasis di Asia, menyediakan berbagai layanan perjalanan yang komprehensif kepada pelanggan kami. Dengan tim profesional yang berpengalaman dan pengetahuan mendalam tentang destinasi di seluruh Asia, kami berkomitmen untuk memberikan pengalaman perjalanan yang tak
               terlupakan kepada pelanggan kami. Dari paket liburan yang disesuaikan hingga pemesanan tiket dan pengaturan akomodasi, kami menyediakan solusi perjalanan yang sesuai dengan kebutuhan dan anggaran Anda. Segera rencanakan liburan Anda bersama kami dan jelajahi keindahan Asia dengan Asian Tour and Travel.</p>
               <h3>Visi Misi</h3>

            <p>1.Menyediakan layanan perjalanan berkualitas tinggi yang memenuhi kebutuhan dan keinginan pelanggan kami.<br>
            2.Memperkenalkan destinasi dan pengalaman unik di seluruh Asia kepada pelanggan kami.<br>
            3.Menyediakan layanan perjalanan berkualitas tinggi yang memenuhi kebutuhan dan keinginan pelanggan kami.<br>
            4.Memperkenalkan destinasi dan pengalaman unik di seluruh Asia kepada pelanggan kami.</p>

            </p>
          </div>
        </div>
      </div>
    </div>
  </div>