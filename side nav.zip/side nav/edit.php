<?php
include("koneksi.php");

// Periksa apakah parameter 'id' ada di URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mengambil data berdasarkan ID
    $stmt = $conn->prepare("SELECT * FROM tamu WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Jika data ditemukan
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die("Data tidak ditemukan.");
    }
    $stmt->close();
} else {
    die("ID tidak valid.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Tamu</title>
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.css">
    <script>
        function hitungHarga() {
            const hargaPaket = {
                "A": 500000,
                "B": 600000,
                "C": 700000,
                "D": 800000,
                "E": 900000,
                "F": 1000000,
                "G": 1100000,
                "H": 1200000,
                "I": 1300000,
                "J": 1400000,
                "K": 1500000,
                "L": 1600000
            };

            const tipePaket = document.getElementById("tipe_paket").value;
            const jumlahOrang = parseInt(document.getElementById("jumlah_orang").value) || 0;

            const totalHarga = tipePaket && jumlahOrang > 0 ? hargaPaket[tipePaket] * jumlahOrang : 0;

            document.getElementById("harga_total").value = totalHarga.toLocaleString("id-ID", {
                style: "currency",
                currency: "IDR"
            });
        }
    </script>
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center">Edit Data Tamu</h2>
        <!-- Form untuk mengedit data tamu -->
        <form action="proses_edit.php?id=<?php echo $row['id']; ?>" method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo htmlspecialchars($row['nama']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="judul" class="form-label">Judul</label>
                <input type="text" class="form-control" id="judul" name="judul" value="<?php echo htmlspecialchars($row['judul']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="tanggal_keberangkatan" class="form-label">Tanggal Keberangkatan</label>
                <input type="date" class="form-control" id="tanggal_keberangkatan" name="tanggal_keberangkatan" value="<?php echo htmlspecialchars($row['tanggal_keberangkatan']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="jumlah_orang" class="form-label">Jumlah Orang</label>
                <input type="number" class="form-control" id="jumlah_orang" name="jumlah_orang" value="<?php echo htmlspecialchars($row['jumlah_orang']); ?>" oninput="hitungHarga()" required>
            </div>
            <div class="form-group">
                <label for="tipe_paket">Tipe Paket</label>
                <select name="tipe_paket" id="tipe_paket" class="form-control" onchange="hitungHarga()" required>
                    <option value="" disabled>Pilih Paket</option>
                    <?php
                    $paket_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'];
                    foreach ($paket_list as $paket) {
                        $selected = ($row['tipe_paket'] === $paket) ? 'selected' : '';
                        echo "<option value=\"$paket\" $selected>Paket $paket</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="harga_total" class="form-label">Harga Total</label>
                <input type="text" class="form-control" id="harga_total" value="<?php echo number_format($row['harga_total'], 0, ',', '.'); ?>" readonly>
            </div>
            
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="tampil.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</body>

</html>
