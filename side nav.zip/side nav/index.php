<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="asset/logo.png" type="image/x-icon" />
    <title>Asia Tour || HOME</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
.container {
  position: relative;
  width: 100%;
  overflow: hidden;
  padding-top: 56.25%; /* 16:9 Aspect Ratio */
  
}

.responsive-iframe {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
  border: none;
}
</style>
</head>
<body>
  <?php 
    include "navbar.php";
    include "koneksi.php";
   ?>
<br>
  <center><h2>Selamat Datang Asia Travel</h2></center> 
   
  <div class="container-fluid carousel-container">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="./asset/Southeast-Asia-Tour.jpg" class="d-block fit-image" alt="..." />
        </div>
        <div class="carousel-item">
          <img src="./asset/tours-travel.jpg" class="d-block fit-image" alt="..." />
        </div>
        <div class="carousel-item">
          <img src="./asset/japan.png" class="d-block fit-image" alt="..." />
        </div>
      </div>
    </div>
  </div>
<br><br>
  <div class="container">
  <iframe class="responsive-iframe" src="https://www.youtube.com/embed/ThI0pBAbFnk?si=mNkF2KtpM-NQe9PJ"></iframe>
</div>
 
</body>
</html>

